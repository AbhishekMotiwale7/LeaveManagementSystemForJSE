﻿using AutoMapper;
using LeaveManagement.Data.Migrations;
using LeaveManagement.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace LeaveManagement.Controllers
{
    [Authorize(Roles = "Manager")]
    public class LeaveManagementController : Controller
    {
        private readonly IMapper _mapper;
        private readonly UserManager<Employee> _userManager;

        public LeaveManagementController(
            IMapper mapper,
            UserManager<Employee> userManager
        )
        {
            _mapper = mapper;
            _userManager = userManager;
        }

        // GET: LeaveManagementController
        public ActionResult Index()
        {
            var employees = _userManager.GetUsersInRoleAsync("Employee").Result;
            var model = _mapper.Map<List<EmployeeVM>>(employees);
            return View(model);
        }
    }
}
