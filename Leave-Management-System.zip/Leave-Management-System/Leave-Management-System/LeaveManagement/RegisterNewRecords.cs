﻿using LeaveManagement.Data.Migrations;
using LeaveManagement.EmployeeData.Model;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace LeaveManagement
{
    public static class RegisterNewRecords
    {
        public static void Add(UserManager<Employee> userManager,
            RoleManager<IdentityRole> roleManager)
        {
            AddRoles(roleManager);
            AddEmployee(userManager);
        }

        private static void AddEmployee(UserManager<Employee> userManager)
        {
            if (userManager.FindByNameAsync("lindajenkins@acme.com").Result == null)
            {
                List<EmployeeDetails> employeeDetailsList = new List<EmployeeDetails>();
                employeeDetailsList = GetEmployeeDetails();
                if (employeeDetailsList == null) return;
                foreach (EmployeeDetails employeeDetails in employeeDetailsList)
                {
                    var user = new Employee
                    {
                        EmployeeNumber = employeeDetails.EmployeeNumber,
                        UserName = employeeDetails.Email,
                        Email = employeeDetails.Email,
                        PhoneNumber = employeeDetails.PhoneNumber,
                        Firstname = employeeDetails.Firstname,
                        Lastname = employeeDetails.Lastname,
                        ReportingTo = employeeDetails.ReportingTo
                    };

                    var result = userManager.CreateAsync(user, "JseTest@123").Result;
                    if (result.Succeeded)
                    {
                        string role = string.Empty;
                        if (employeeDetails.EmployeeNumber == "0001" || employeeDetails.EmployeeNumber == "0002" || employeeDetails.EmployeeNumber == "0003") role = "Manager";
                        else role = "Employee";
                        userManager.AddToRoleAsync(user, role).Wait();
                    }
                }
            }
        }

        private static void AddRoles(RoleManager<IdentityRole> roleManager)
        {
            //if (!roleManager.RoleExistsAsync("CEO").Result)
            //{
            //    var role = new IdentityRole
            //    {
            //        Name = "CEO"
            //    };
            //    var result = roleManager.CreateAsync(role).Result;
            //}
            if (!roleManager.RoleExistsAsync("Manager").Result)
            {
                var role = new IdentityRole
                {
                    Name = "Manager"
                };
                var result = roleManager.CreateAsync(role).Result;
            }

            if (!roleManager.RoleExistsAsync("Employee").Result)
            {
                var role = new IdentityRole
                {
                    Name = "Employee"
                };
                var result = roleManager.CreateAsync(role).Result;
            }
        }

        private static List<EmployeeDetails> GetEmployeeDetails()
        {
            var result = new List<EmployeeDetails>();

            XmlDocument doc = new XmlDocument();
            doc.Load(@"EmployeeData\EmployeeRecords.xml");

            XmlNodeList errorNodes = doc.DocumentElement.SelectNodes("/EmployeeRecords/EmployeeDetails");
            foreach (XmlNode nodes in errorNodes)
            {
                EmployeeDetails employeedetailsObj = new EmployeeDetails();

                foreach (XmlNode locNode in nodes)
                {
                    if (string.Equals(locNode.Name, "EmployeeNumber", StringComparison.OrdinalIgnoreCase))
                    {
                        employeedetailsObj.EmployeeNumber = locNode?.InnerText;
                    }
                    if (string.Equals(locNode.Name, "Firstname", StringComparison.OrdinalIgnoreCase))
                    {
                        employeedetailsObj.Firstname = locNode?.InnerText;
                    }
                    if (string.Equals(locNode.Name, "Lastname", StringComparison.OrdinalIgnoreCase))
                    {
                        employeedetailsObj.Lastname = locNode?.InnerText;
                    }
                    if (string.Equals(locNode.Name, "Email", StringComparison.OrdinalIgnoreCase))
                    {
                        employeedetailsObj.Email = locNode?.InnerText;
                    }
                    if (string.Equals(locNode.Name, "PhoneNumber", StringComparison.OrdinalIgnoreCase))
                    {
                        employeedetailsObj.PhoneNumber = locNode?.InnerText;
                    }
                    if (string.Equals(locNode.Name, "UserName", StringComparison.OrdinalIgnoreCase))
                    {
                        employeedetailsObj.UserName = locNode?.InnerText;
                    }
                    if (string.Equals(locNode.Name, "ReportingTo", StringComparison.OrdinalIgnoreCase))
                    {
                        employeedetailsObj.ReportingTo = locNode?.InnerText;
                    }
                }
                result.Add(employeedetailsObj);
            }

            //XmlSerializer ser = new XmlSerializer(typeof(EmployeesDirectory), new XmlRootAttribute("EmployeeRecords"));
            //FileStream myFileStream = new FileStream(@"EmployeeData\EmployeeRecords.xml", FileMode.Open);
            //return ((EmployeesDirectory)ser.Deserialize(myFileStream)).Employees;

            return result;
        }
    }
}
