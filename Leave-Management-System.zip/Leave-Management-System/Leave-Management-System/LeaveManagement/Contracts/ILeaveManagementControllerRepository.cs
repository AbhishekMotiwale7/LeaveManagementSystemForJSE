﻿using LeaveManagement.Data;
using System.Collections.Generic;

namespace LeaveManagement.Contracts
{
    public interface ILeaveManagementControllerRepository : IRepositoryBase<LeaveAllocation>
    {
        ICollection<LeaveAllocation> GetLeaveAllocationsByEmployee(string employeeid);
        LeaveAllocation GetLeaveAllocationsByEmployeeAndType(string employeeid, int leavetypeid);
    }
}
