﻿using LeaveManagement.Data;
using System.Collections.Generic;

namespace LeaveManagement.Contracts
{
    public interface ILeaveRequestRepository : IRepositoryBase<LeaveRequest>
    {
        ICollection<LeaveRequest> GetLeaveRequestsByEmployee(string employeeid);
        public ICollection<LeaveRequest> GetAllEmployeeLeaveRequestsByManager(string managerEmpNum);
    }
}
