﻿namespace LeaveManagement.Utilities
{
    public static class DefaultLeaveType
    {
        public static string[] LeaveTypes = { "Annual Leave", "Casual Leave", "Sick Leave" };
        public static int NumberOfDays = 10;
    }

    public static class Utility
    {
        public static string CEO = "lindajenkins@acme.com";
        public static string Password = "JseTest@123";
        public static string[] EmployeeRoles = { "Manager", "Employee" };
        public static string EmployeeRecordsFilePath = @"EmployeeData\EmployeeRecords.xml";
        public static string Manager = "Manager";
        public static string Employee = "Employee";
    }
}
