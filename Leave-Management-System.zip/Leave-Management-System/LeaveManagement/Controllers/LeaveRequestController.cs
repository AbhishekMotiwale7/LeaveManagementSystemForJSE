﻿using LeaveManagement.BusinessLogic.Interface;
using LeaveManagement.Data.Migrations;
using LeaveManagement.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;

namespace LeaveManagement.Controllers
{
    [Authorize]
    public class LeaveRequestController : Controller
    {
        private readonly UserManager<Employee> _userManager;
        private readonly ILeaveRequestBL _leaveRequestBL;
        public LeaveRequestController(
            ILeaveRequestBL leaveRequestBL,
            UserManager<Employee> userManager
        )
        {
            _userManager = userManager;
            _leaveRequestBL = leaveRequestBL;
        }

        [Authorize(Roles = "Manager")]
        public ActionResult Index()
        {
            try
            {
                var employee = _userManager.GetUserAsync(User).Result;
                var adminLeaveRequestViewVM = _leaveRequestBL.GetAllLeaveRequestsDetails(employee.EmployeeNumber);
                return View(adminLeaveRequestViewVM);
            }
            catch (Exception ex)
            {
                return RedirectToAction(nameof(Index));
            }
        }

        public ActionResult MyLeave()
        {
            try
            {
                var employee = _userManager.GetUserAsync(User).Result;
                var employeeLeaveRequestViewVM = _leaveRequestBL.MyLeave(employee.Id);
                return View(employeeLeaveRequestViewVM);
            }
            catch (Exception ex)
            {
                return RedirectToAction(nameof(Index));
            }
        }

        public ActionResult ApproveRequest(int id)
        {
            try
            {
                var user = _userManager.GetUserAsync(User).Result;
                var isApproveRequest = _leaveRequestBL.ApproveRequest(id, user.Id);
                if (!isApproveRequest)
                {
                    return BadRequest();
                }

                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                return RedirectToAction(nameof(Index));
            }
        }

        public ActionResult RejectRequest(int id)
        {
            try
            {
                var user = _userManager.GetUserAsync(User).Result;
                var isRequestRejected = _leaveRequestBL.RejectRequest(id, user.Id);

                if (!isRequestRejected)
                {
                    return BadRequest();
                }

                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                return RedirectToAction(nameof(Index));
            }

        }

        public ActionResult Create()
        {
            try
            {
                var model = _leaveRequestBL.LoadCreatePageData();
                return View(model);
            }
            catch (Exception ex)
            {
                return RedirectToAction(nameof(Index));
            }
        }

        [HttpPost]
        public ActionResult Create(CreateLeaveRequestVM model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    ModelState.AddModelError("", "Something went wrong");
                    return RedirectToAction(nameof(Index));
                }

                var employee = _userManager.GetUserAsync(User).Result;
                var leaveRequestActionResult = _leaveRequestBL.Create(model, employee.Id);

                if (!leaveRequestActionResult.IsSuccess)
                {
                    ModelState.AddModelError("", leaveRequestActionResult.ErrorMessage);
                    return View(model);
                }
                return RedirectToAction("MyLeave");
            }
            catch (Exception)
            {
                ModelState.AddModelError("", "Something went wrong");
                return View(model);
            }
        }

        public ActionResult CancelRequest(int id)
        {
            var isSuccess = _leaveRequestBL.CancelRequest(id);
            if (!isSuccess)
            {
                return BadRequest();
            }
            return RedirectToAction("MyLeave");
        }

        public ActionResult DeleteRequest(int id)
        {
            try
            {
                var isSuccess = _leaveRequestBL.DeleteRequest(id);
                if (!isSuccess)
                {
                    return BadRequest();
                }
                return RedirectToAction("MyLeave");

            }
            catch
            {
                return View();
            }
        }

        public ActionResult Edit(int id)
        {
            var model = _leaveRequestBL.LoadEditPageData(id);
            return View(model);
        }

        [HttpPost]
        public ActionResult Edit(CreateLeaveRequestVM model)
        {
            try
            {
                var employee = _userManager.GetUserAsync(User).Result;
                var leaveRequestActionResult = _leaveRequestBL.Edit(model, employee.Id);

                if (!leaveRequestActionResult.IsSuccess)
                {
                    ModelState.AddModelError("", leaveRequestActionResult.ErrorMessage);
                    return View(model);
                }

                return RedirectToAction("MyLeave");
            }
            catch
            {
                return View(model);
            }
        }

        public ActionResult Details(int id)
        {
            var model = _leaveRequestBL.Details(id);
            return View(model);
        }

    }
}
