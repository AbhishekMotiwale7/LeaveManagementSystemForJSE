﻿using AutoMapper;
using LeaveManagement.BusinessLogic.Interface;
using LeaveManagement.Models;
using LeaveManagement.Repository.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;

namespace LeaveManagement.Controllers
{
    [Authorize(Roles = "Manager")]
    public class LeaveTypesController : Controller
    {
        private readonly ILeaveTypeRepository _leaveTypeRepository;
        private readonly ILeaveTypeBL _leaveTypeBL;
        public LeaveTypesController(ILeaveTypeBL leaveTypeBL, IMapper mapper)
        {
            _leaveTypeBL = leaveTypeBL;
        }

        // GET: LeaveTypesController       
        public ActionResult Index()
        {
            try
            {
                var model = _leaveTypeBL.GetLeaveTypes();
                return View(model);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Something went wrong!");
                return RedirectToAction(nameof(Index));
            }
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(LeaveTypeVM model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return View(model);
                }
                var result = _leaveTypeBL.Create(model);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Something went wrong!");
                return View(model);
            }
        }

        public ActionResult Delete(int id)
        {
            try
            {
                var isSuccess = _leaveTypeBL.Delete(id);
                if (!isSuccess)
                {
                    return BadRequest();
                }
            }
            catch (Exception ex) { ModelState.AddModelError("", "Something went wrong!"); }
            return RedirectToAction(nameof(Index));
        }

    }
}
