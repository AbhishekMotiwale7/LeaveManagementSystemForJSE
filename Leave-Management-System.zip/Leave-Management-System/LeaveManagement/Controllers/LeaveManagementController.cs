﻿using LeaveManagement.BusinessLogic.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LeaveManagement.Controllers
{
    [Authorize(Roles = "Manager")]
    public class LeaveManagementController : Controller
    {
        private readonly ILeaveManagementBL _leaveManagementBL;

        public LeaveManagementController(
            ILeaveManagementBL leaveManagementBL
        )
        {
            _leaveManagementBL = leaveManagementBL;
        }

        // GET: LeaveManagementController
        public ActionResult Index()
        {
            var model = _leaveManagementBL.GetEmployee();
            return View(model);
        }
    }
}
