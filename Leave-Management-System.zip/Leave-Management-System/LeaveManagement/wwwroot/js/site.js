﻿$(document).ready(function () {
    $('#tblData').DataTable();
});