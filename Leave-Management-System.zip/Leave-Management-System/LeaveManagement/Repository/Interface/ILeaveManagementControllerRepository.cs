﻿using LeaveManagement.Data;
using System.Collections.Generic;

namespace LeaveManagement.Repository.Interface
{
    public interface ILeaveManagementControllerRepository : IRepositoryBase<LeaveAllocation>
    {
        ICollection<LeaveAllocation> GetLeaveAllocationsByEmployee(string employeeid);
        LeaveAllocation GetLeaveAllocationsByEmployeeAndType(string employeeid, int leavetypeid);
    }
}
