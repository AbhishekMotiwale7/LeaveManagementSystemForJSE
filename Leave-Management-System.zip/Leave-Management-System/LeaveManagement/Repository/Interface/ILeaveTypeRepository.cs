﻿using LeaveManagement.Data;

namespace LeaveManagement.Repository.Interface
{
    public interface ILeaveTypeRepository : IRepositoryBase<LeaveType>
    {
    }
}
