﻿namespace LeaveManagement.EmployeeData.Model
{
    public class EmployeeDetails
    {
        public string EmployeeNumber { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public string Email { get; set; }
        public string? PhoneNumber { get; set; }
        public string UserName { get; set; }
        public string? ReportingTo { get; set; }
        public string? EmployeeRole { get; set; }
    }

    public class EmployeesDirectory
    {
        public EmployeeDetails[] Employees { get; set; }
    }
}
