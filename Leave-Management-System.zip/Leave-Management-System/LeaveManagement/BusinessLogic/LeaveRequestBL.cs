﻿using AutoMapper;
using LeaveManagement.BusinessLogic.Interface;
using LeaveManagement.Data;
using LeaveManagement.Models;
using LeaveManagement.Repository.Interface;
using LeaveManagement.Utilities;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.CodeAnalysis;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LeaveManagement.BusinessLogic
{
    public class LeaveRequestBL : ILeaveRequestBL
    {
        private readonly ILeaveRequestRepository _leaveRequestRepo;
        private readonly ILeaveTypeRepository _leaveTypeRepo;
        private readonly ILeaveManagementControllerRepository _leaveAllocRepo;
        private readonly IMapper _mapper;
        public LeaveRequestBL(ILeaveRequestRepository leaveRequestRepo,
             ILeaveTypeRepository leaveTypeRepo,
             IMapper mapper,
             ILeaveManagementControllerRepository leaveAllocRepo)
        {

            _leaveRequestRepo = leaveRequestRepo;
            _leaveTypeRepo = leaveTypeRepo;
            _leaveAllocRepo = leaveAllocRepo;
            _mapper = mapper;
        }
        public EmployeeLeaveRequestViewVM MyLeave(string employeeId)
        {
            try
            {
                var employeeAllocations = _leaveAllocRepo.GetLeaveAllocationsByEmployee(employeeId);
                var employeeRequests = _leaveRequestRepo.GetLeaveRequestsByEmployee(employeeId);

                var employeeAllocationsModel = _mapper.Map<List<LeaveAllocationVM>>(employeeAllocations);
                var employeeRequestsModel = _mapper.Map<List<LeaveRequestVM>>(employeeRequests);

                var model = new EmployeeLeaveRequestViewVM
                {
                    LeaveAllocations = employeeAllocationsModel,
                    LeaveRequests = employeeRequestsModel
                };

                return model;
            }
            catch (Exception ex) { throw ex; }
        }

        public AdminLeaveRequestViewVM GetAllLeaveRequestsDetails(string employeeNumber)
        {
            try
            {
                ICollection<LeaveRequest> leaveRequests;

                if (employeeNumber != "0001")
                    leaveRequests = _leaveRequestRepo.GetAllEmployeeLeaveRequestsByManager(employeeNumber);
                else
                    leaveRequests = _leaveRequestRepo.FindAll();

                var leaveRequestsModel = _mapper.Map<List<LeaveRequestVM>>(leaveRequests);
                var model = new AdminLeaveRequestViewVM
                {
                    TotalRequests = leaveRequestsModel.Count,
                    ApprovedRequests = leaveRequestsModel.Count(q => q.Approved == true),
                    PendingRequests = leaveRequestsModel.Count(q => q.Approved == null),
                    RejectedRequests = leaveRequestsModel.Count(q => q.Approved == false),
                    LeaveRequests = leaveRequestsModel
                };

                return model;
            }
            catch (Exception ex) { throw ex; }
        }

        public bool ApproveRequest(int leaveRequestId, string employeeId)
        {
            bool result = false;
            try
            {
                var leaveRequest = _leaveRequestRepo.FindById(leaveRequestId);
                var employeeid = leaveRequest.RequestingEmployeeId;
                var leaveTypeid = leaveRequest.LeaveTypeId;
                var allocation = _leaveAllocRepo.GetLeaveAllocationsByEmployeeAndType(employeeid, leaveTypeid);
                int daysRequested = (int)(leaveRequest.EndDate - leaveRequest.StartDate).TotalDays;
                allocation.NumberOfDays = (allocation.NumberOfDays - daysRequested) <= 0 ? DefaultLeaveType.NumberOfDays : allocation.NumberOfDays - daysRequested;

                leaveRequest.Approved = true;
                leaveRequest.ApprovedById = employeeId;
                leaveRequest.DateActioned = DateTime.Now;

                _leaveRequestRepo.Update(leaveRequest);
                _leaveAllocRepo.Update(allocation);
                result = true;
            }
            catch (Exception ex)
            {
                result = false;
                throw ex;
            }
            return result;
        }
        public bool RejectRequest(int leaveRequestId, string employeeId)
        {
            bool result = false;
            try
            {
                var leaveRequest = _leaveRequestRepo.FindById(leaveRequestId);
                var allocation = _leaveAllocRepo.GetLeaveAllocationsByEmployeeAndType(leaveRequest.RequestingEmployeeId, leaveRequest.LeaveTypeId);
                leaveRequest.Approved = false;
                leaveRequest.ApprovedById = employeeId;
                leaveRequest.DateActioned = DateTime.Now;

                int daysRequested = (int)(leaveRequest.EndDate - leaveRequest.StartDate).TotalDays;
                allocation.NumberOfDays = (allocation.NumberOfDays - daysRequested) <= 0 ? DefaultLeaveType.NumberOfDays : allocation.NumberOfDays - daysRequested;
                _leaveAllocRepo.Update(allocation);

                _leaveRequestRepo.Update(leaveRequest);
                result = true;
            }
            catch (Exception ex)
            {
                result = false;
                throw ex;
            }
            return result;
        }

        public CreateLeaveRequestVM LoadCreatePageData()
        {
            try
            {
                var leaveTypes = _leaveTypeRepo.FindAll();
                if (leaveTypes.Count == 0)
                {
                    foreach (string item in DefaultLeaveType.LeaveTypes)
                    {
                        LeaveType leaveType = new LeaveType();
                        leaveType.Name = item;
                        leaveType.DefaultDays = DefaultLeaveType.NumberOfDays;
                        _leaveTypeRepo.Create(leaveType);
                    }

                    leaveTypes = _leaveTypeRepo.FindAll();
                }
                var leaveTypeItems = leaveTypes.Select(q => new SelectListItem
                {
                    Text = q.Name,
                    Value = q.Id.ToString()
                });
                var model = new CreateLeaveRequestVM
                {
                    LeaveTypes = leaveTypeItems
                };

                return model;
            }
            catch (Exception ex) { throw ex; }
        }

        public LeaveRequestActionResult Create(CreateLeaveRequestVM model, string employeeId)
        {
            try
            {
                LeaveRequestActionResult leaveRequestActionResult = new LeaveRequestActionResult();

                var startDate = Convert.ToDateTime(model.StartDate);
                var endDate = Convert.ToDateTime(model.EndDate);
                var leaveTypes = _leaveTypeRepo.FindAll();
                var leaveTypeItems = leaveTypes.Select(q => new SelectListItem
                {
                    Text = q.Name,
                    Value = q.Id.ToString()
                });
                model.LeaveTypes = leaveTypeItems;

                if (DateTime.Compare(startDate, endDate) >= 1)
                {
                    leaveRequestActionResult.IsSuccess = false;
                    leaveRequestActionResult.ErrorMessage = "Start date cannot be further in the future than the end date";
                    return leaveRequestActionResult;
                }

                var allocation = _leaveAllocRepo.GetLeaveAllocationsByEmployeeAndType(employeeId, model.LeaveTypeId);
                if (allocation == null)
                {
                    LeaveAllocation allocateLeave = new LeaveAllocation();
                    allocateLeave.EmployeeId = employeeId;
                    allocateLeave.LeaveTypeId = model.LeaveTypeId;
                    allocateLeave.NumberOfDays = leaveTypes.FirstOrDefault(q => q.Id == model.LeaveTypeId).DefaultDays;
                    allocateLeave.Period = DateTime.Now.Year;
                    allocateLeave.DateCreated = DateTime.Now;
                    _leaveAllocRepo.Create(allocateLeave);

                    allocation = _leaveAllocRepo.GetLeaveAllocationsByEmployeeAndType(employeeId, model.LeaveTypeId);
                }
                int daysRequested = (int)(endDate - startDate).TotalDays;

                if (daysRequested > allocation.NumberOfDays)
                {
                    leaveRequestActionResult.IsSuccess = false;
                    leaveRequestActionResult.ErrorMessage = "You do not have sufficient days for this request!";
                    return leaveRequestActionResult;
                }

                var leaveRequestModel = new LeaveRequestVM
                {
                    RequestingEmployeeId = employeeId,
                    StartDate = startDate,
                    EndDate = endDate,
                    Approved = null,
                    DateRequested = DateTime.Now,
                    DateActioned = DateTime.Now,
                    LeaveTypeId = model.LeaveTypeId,
                    RequestComments = model.RequestComments
                };

                var leaveRequest = _mapper.Map<LeaveRequest>(leaveRequestModel);
                var isSuccess = _leaveRequestRepo.Create(leaveRequest);

                if (!isSuccess)
                {
                    leaveRequestActionResult.IsSuccess = false;
                    leaveRequestActionResult.ErrorMessage = "Something went wrong with submitting your record";
                    return leaveRequestActionResult;
                }

                allocation.NumberOfDays = (allocation.NumberOfDays - daysRequested) <= 0 ? DefaultLeaveType.NumberOfDays : allocation.NumberOfDays - daysRequested;
                _leaveAllocRepo.Update(allocation);

                leaveRequestActionResult.IsSuccess = true;
                leaveRequestActionResult.ErrorMessage = "";
                return leaveRequestActionResult;
            }
            catch (Exception ex) { throw ex; }
        }

        public bool CancelRequest(int leaveRequestId)
        {
            try
            {
                var leaveRequest = _leaveRequestRepo.FindById(leaveRequestId);
                leaveRequest.Cancelled = true;
                return _leaveRequestRepo.Update(leaveRequest);
            }
            catch (Exception ex) { throw ex; }
        }
        public bool DeleteRequest(int leaveRequestId)
        {
            try
            {
                var leaveRequest = _leaveRequestRepo.FindById(leaveRequestId);

                var allocation = _leaveAllocRepo.GetLeaveAllocationsByEmployeeAndType(leaveRequest.RequestingEmployeeId, leaveRequest.LeaveTypeId);
                int daysRequested = (int)(leaveRequest.EndDate - leaveRequest.StartDate).TotalDays;
                allocation.NumberOfDays = (allocation.NumberOfDays + daysRequested) > DefaultLeaveType.NumberOfDays ? DefaultLeaveType.NumberOfDays : allocation.NumberOfDays + daysRequested;
                _leaveRequestRepo.Delete(leaveRequest);
                return _leaveAllocRepo.Update(allocation);
            }
            catch (Exception ex) { throw ex; }
        }

        public CreateLeaveRequestVM LoadEditPageData(int leaveRequestId)
        {
            try
            {
                var leaveTypes = _leaveTypeRepo.FindAll();
                var leaveTypeItems = leaveTypes.Select(q => new SelectListItem
                {
                    Text = q.Name,
                    Value = q.Id.ToString()
                });
                var leaveRequest = _leaveRequestRepo.FindById(leaveRequestId);


                var model = new CreateLeaveRequestVM
                {
                    LeaveTypes = leaveTypeItems,
                    StartDate = leaveRequest.StartDate.ToString(),
                    EndDate = leaveRequest.EndDate.ToString(),
                    RequestComments = leaveRequest.RequestComments,
                    LeaveRequestId = leaveRequestId
                };

                return model;
            }
            catch (Exception ex) { throw ex; }
        }

        public LeaveRequestActionResult Edit(CreateLeaveRequestVM model, string employeeId)
        {
            try
            {
                LeaveRequestActionResult leaveRequestActionResult = new LeaveRequestActionResult();

                var startDate = Convert.ToDateTime(model.StartDate);
                var endDate = Convert.ToDateTime(model.EndDate);
                var leaveTypes = _leaveTypeRepo.FindAll();
                var leaveTypeItems = leaveTypes.Select(q => new SelectListItem
                {
                    Text = q.Name,
                    Value = q.Id.ToString()
                });
                model.LeaveTypes = leaveTypeItems;


                if (DateTime.Compare(startDate, endDate) >= 1)
                {
                    leaveRequestActionResult.IsSuccess = false;
                    leaveRequestActionResult.ErrorMessage = "Start date cannot be further in the future than the end date";
                    return leaveRequestActionResult;
                }

                var allocation = _leaveAllocRepo.GetLeaveAllocationsByEmployeeAndType(employeeId, model.LeaveTypeId);
                int daysRequested = (int)(endDate - startDate).TotalDays;

                if (daysRequested > allocation.NumberOfDays)
                {
                    leaveRequestActionResult.IsSuccess = false;
                    leaveRequestActionResult.ErrorMessage = "You do not have sufficient days for this request!";
                    return leaveRequestActionResult;
                }

                var leaveRequestModel = new LeaveRequestVM
                {
                    Id = model.LeaveRequestId,
                    RequestingEmployeeId = employeeId,
                    StartDate = startDate,
                    EndDate = endDate,
                    Approved = null,
                    DateRequested = DateTime.Now,
                    DateActioned = DateTime.Now,
                    LeaveTypeId = model.LeaveTypeId,
                    RequestComments = model.RequestComments
                };

                var leaveRequest = _mapper.Map<LeaveRequest>(leaveRequestModel);
                var isSuccess = _leaveRequestRepo.Update(leaveRequest);

                if (!isSuccess)
                {
                    leaveRequestActionResult.IsSuccess = false;
                    leaveRequestActionResult.ErrorMessage = "Something went wrong with editing your record";
                    return leaveRequestActionResult;
                }

                leaveRequestActionResult.IsSuccess = true;
                leaveRequestActionResult.ErrorMessage = "";
                return leaveRequestActionResult;
            }
            catch (Exception ex) { throw ex; }
        }

        public LeaveRequestVM Details(int leaveRequestId)
        {
            try
            {
                var leaveRequest = _leaveRequestRepo.FindById(leaveRequestId);
                var model = _mapper.Map<LeaveRequestVM>(leaveRequest);
                return model;
            }
            catch (Exception ex) { throw ex; }
        }

    }
}
