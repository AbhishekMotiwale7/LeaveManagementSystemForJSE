﻿using AutoMapper;
using LeaveManagement.BusinessLogic.Interface;
using LeaveManagement.Data.Migrations;
using LeaveManagement.Models;
using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;

namespace LeaveManagement.BusinessLogic
{
    public class LeaveManagementBL : ILeaveManagementBL
    {
        private readonly IMapper _mapper;
        private readonly UserManager<Employee> _userManager;
        public LeaveManagementBL(IMapper mapper,
            UserManager<Employee> userManager
        )
        {
            _mapper = mapper;
            _userManager = userManager;
        }
        public List<EmployeeVM> GetEmployee()
        {
            var employees = _userManager.GetUsersInRoleAsync("Employee").Result;
            var model = _mapper.Map<List<EmployeeVM>>(employees);
            return model;
        }

    }
}
