﻿using AutoMapper;
using LeaveManagement.BusinessLogic.Interface;
using LeaveManagement.Data;
using LeaveManagement.Models;
using LeaveManagement.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LeaveManagement.BusinessLogic
{
    public class LeaveTypeBL : ILeaveTypeBL
    {
        private readonly ILeaveTypeRepository _leaveTypeRepository;
        private readonly IMapper _mapper;
        public LeaveTypeBL(ILeaveTypeRepository repo, IMapper mapper)
        {
            _leaveTypeRepository = repo;
            _mapper = mapper;
        }

        public List<LeaveTypeVM> GetLeaveTypes()
        {
            try
            {
                var leavetypes = _leaveTypeRepository.FindAll().ToList();
                var model = _mapper.Map<List<LeaveType>, List<LeaveTypeVM>>(leavetypes);
                return model;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public LeaveTypeVM Create(LeaveTypeVM model)
        {
            try
            {
                var leaveType = _mapper.Map<LeaveType>(model);
                leaveType.DateCreated = DateTime.Now;
                var isSuccess = _leaveTypeRepository.Create(leaveType);
                return model;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Delete(int leaveTypeId)
        {
            var leavetype = _leaveTypeRepository.FindById(leaveTypeId);
            if (leavetype == null)
            {
                return false;
            }
            return _leaveTypeRepository.Delete(leavetype);
        }
    }
}
