﻿using LeaveManagement.Models;
using System.Collections.Generic;

namespace LeaveManagement.BusinessLogic.Interface
{
    public interface ILeaveTypeBL
    {
        List<LeaveTypeVM> GetLeaveTypes();
        LeaveTypeVM Create(LeaveTypeVM model);
        bool Delete(int leaveTypeId);
    }
}
