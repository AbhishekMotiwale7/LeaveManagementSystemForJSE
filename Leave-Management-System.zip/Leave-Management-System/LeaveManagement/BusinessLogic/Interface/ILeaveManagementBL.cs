﻿using LeaveManagement.Models;
using System.Collections.Generic;

namespace LeaveManagement.BusinessLogic.Interface
{
    public interface ILeaveManagementBL
    {
        List<EmployeeVM> GetEmployee();
    }
}
