﻿using LeaveManagement.Models;

namespace LeaveManagement.BusinessLogic.Interface
{
    public interface ILeaveRequestBL
    {
        EmployeeLeaveRequestViewVM MyLeave(string employeeId);
        AdminLeaveRequestViewVM GetAllLeaveRequestsDetails(string employeeNumber);
        bool ApproveRequest(int leaveRequestId, string employeeId);
        bool RejectRequest(int leaveRequestId, string employeeId);
        CreateLeaveRequestVM LoadCreatePageData();
        LeaveRequestActionResult Create(CreateLeaveRequestVM model, string employeeId);
        bool CancelRequest(int leaveRequestId);
        bool DeleteRequest(int leaveRequestId);
        CreateLeaveRequestVM LoadEditPageData(int leaveRequestId);
        LeaveRequestActionResult Edit(CreateLeaveRequestVM model, string employeeId);
        LeaveRequestVM Details(int leaveRequestId);
    }
}