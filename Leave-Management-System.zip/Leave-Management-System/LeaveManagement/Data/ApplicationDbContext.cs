﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace LeaveManagement.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<LeaveAllocation> LeaveAllocations { get; set; }
        public DbSet<LeaveType> LeaveTypes { get; set; }
        public DbSet<LeaveRequest> LeaveRequests { get; set; }

        // public DbSet<Employee> Employees { get; set; }
        //public DbSet<LeaveManagement.Models.LeaveRequestVM> LeaveRequestVM { get; set; }
        //public DbSet<LeaveManagement.Models.EmployeeVM> EmployeeVM { get; set; }

    }
}
