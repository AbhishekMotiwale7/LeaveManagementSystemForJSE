﻿using System;
using System.ComponentModel.DataAnnotations;

namespace LeaveManagement.Data
{
    public class LeaveType
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public int DefaultDays { get; set; }
        public DateTime DateCreated { get; set; }
    }

    //public static class DefaultLeaveType
    //{
    //    public static string[] LeaveTypes = { "Annual Leave", "Casual Leave", "Sick Leave" };
    //    public static int NumberOfDays = 10;
    //}
}
