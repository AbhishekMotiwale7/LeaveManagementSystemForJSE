﻿using LeaveManagement.Data.Migrations;
using LeaveManagement.EmployeeData.Model;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Xml;

namespace LeaveManagement
{
    public static class RegisterNewRecords
    {
        public static void Add(UserManager<Employee> userManager,
            RoleManager<IdentityRole> roleManager)
        {
            AddRoles(roleManager);
            AddEmployee(userManager);
        }

        private static void AddEmployee(UserManager<Employee> userManager)
        {
            if (userManager.FindByNameAsync(Utilities.Utility.CEO).Result == null)
            {
                List<EmployeeDetails> employeeDetailsList = new List<EmployeeDetails>();
                employeeDetailsList = GetEmployeeDetails();
                if (employeeDetailsList == null) return;
                foreach (EmployeeDetails employeeDetails in employeeDetailsList)
                {
                    var user = new Employee
                    {
                        EmployeeNumber = employeeDetails.EmployeeNumber,
                        UserName = employeeDetails.Email,
                        Email = employeeDetails.Email,
                        PhoneNumber = employeeDetails.PhoneNumber,
                        Firstname = employeeDetails.Firstname,
                        Lastname = employeeDetails.Lastname,
                        ReportingTo = employeeDetails.ReportingTo,
                    };

                    var result = userManager.CreateAsync(user, Utilities.Utility.Password).Result;
                    if (result.Succeeded)
                    {
                        userManager.AddToRoleAsync(user, employeeDetails.EmployeeRole).Wait();
                    }
                }
            }
        }

        private static void AddRoles(RoleManager<IdentityRole> roleManager)
        {
            foreach (string employeeRole in Utilities.Utility.EmployeeRoles)
            {
                if (!roleManager.RoleExistsAsync(employeeRole).Result)
                {
                    var role = new IdentityRole
                    {
                        Name = employeeRole
                    };
                    var result = roleManager.CreateAsync(role).Result;
                }
            }

        }

        private static List<EmployeeDetails> GetEmployeeDetails()
        {
            var result = new List<EmployeeDetails>();

            XmlDocument doc = new XmlDocument();
            doc.Load(Utilities.Utility.EmployeeRecordsFilePath);

            XmlNodeList errorNodes = doc.DocumentElement.SelectNodes("/EmployeeRecords/EmployeeDetails");
            foreach (XmlNode nodes in errorNodes)
            {
                EmployeeDetails employeedetailsObj = new EmployeeDetails();

                foreach (XmlNode locNode in nodes)
                {
                    if (string.Equals(locNode.Name, "EmployeeNumber", StringComparison.OrdinalIgnoreCase))
                    {
                        employeedetailsObj.EmployeeNumber = locNode?.InnerText;
                    }
                    if (string.Equals(locNode.Name, "Firstname", StringComparison.OrdinalIgnoreCase))
                    {
                        employeedetailsObj.Firstname = locNode?.InnerText;
                    }
                    if (string.Equals(locNode.Name, "Lastname", StringComparison.OrdinalIgnoreCase))
                    {
                        employeedetailsObj.Lastname = locNode?.InnerText;
                    }
                    if (string.Equals(locNode.Name, "Email", StringComparison.OrdinalIgnoreCase))
                    {
                        employeedetailsObj.Email = locNode?.InnerText;
                    }
                    if (string.Equals(locNode.Name, "PhoneNumber", StringComparison.OrdinalIgnoreCase))
                    {
                        employeedetailsObj.PhoneNumber = locNode?.InnerText;
                    }
                    if (string.Equals(locNode.Name, "UserName", StringComparison.OrdinalIgnoreCase))
                    {
                        employeedetailsObj.UserName = locNode?.InnerText;
                    }
                    if (string.Equals(locNode.Name, "ReportingTo", StringComparison.OrdinalIgnoreCase))
                    {
                        employeedetailsObj.ReportingTo = locNode?.InnerText;
                    }
                    if (string.Equals(locNode.Name, "EmployeeRole", StringComparison.OrdinalIgnoreCase))
                    {
                        employeedetailsObj.EmployeeRole = locNode?.InnerText;
                    }
                }
                result.Add(employeedetailsObj);
            }

            return result;
        }
    }
}
